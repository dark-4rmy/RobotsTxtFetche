-- Create the settings table if it doesn't already exist
CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY,
    user_agent TEXT NOT NULL
);

-- Insert the default user-agent into the settings table
INSERT INTO settings (user_agent) VALUES ('Mozilla/5.0');
